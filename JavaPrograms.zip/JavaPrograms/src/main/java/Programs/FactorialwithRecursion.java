package Programs;

public class FactorialwithRecursion {

    public  static int factorial(int n){
        if(n==0) // base case
            return 1;
        else
            return (n* factorial(n-1));  //recurssive calling same function


    }

    public static void main(String[] args) {
        int i =1;
        int fact =1;
        int number =4;

        fact = factorial(number);
        System.out.println("Factorial of " + number + " is " + fact);
    }


}
