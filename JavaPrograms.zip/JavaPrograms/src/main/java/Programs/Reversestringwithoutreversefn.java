package Programs;

import java.util.Scanner;

public class Reversestringwithoutreversefn {


    //Program to reverse a string without using reverse()function
    //here we are using Scanner class

    public static void main(String[] args) {

        Scanner myobj = new Scanner(System.in);
        System.out.print("Enter the username");
        String username = myobj.nextLine(); //nextline method is used to read string input
        String[]  token = username.split("");//split method is used to print in reverse order





    }
}
