package Programs;

public class Reversestring {

    //Program for reverse a string without string-in built functions
    //Here we are using Stringbuilder
    //In Stringbuilder class we are using append() and reverse() method

    public static void main(String[] args) {


        String str = "Automation"; //variable declarated and assigned
        StringBuilder str2 = new StringBuilder(); //String builder object is created
        str2.append(str);
        str2 = str2.reverse();
        System.out.println(str2);


    }


}
