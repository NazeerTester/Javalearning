package Programs;

import org.omg.Messaging.SyncScopeHelper;

public class FactorialprogramwithLoops {

    //Factorial program using loops
    //Using for loop

    public static void main(String[] args) {
        int i = 1;
        int fact = 1;
        int number = 5;

        for (i = 1; i <= number; i++) {

            fact = fact * i;
            //First loop 1*1=1
            //2nd loop 1*2=2
            //3rd loop 1*3=3
            //4th loop 1*4=4
            //5th loop 1*5=5 //loop ends when i=5
            //5! = 5*4*3*2*1 = 120

        }
        System.out.println("Factorial  of " + number + " is " + fact);


    }
}
