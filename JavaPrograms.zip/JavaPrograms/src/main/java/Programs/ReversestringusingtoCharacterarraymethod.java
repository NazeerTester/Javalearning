package Programs;

public class ReversestringusingtoCharacterarraymethod {

    //reverse string using character array

    public static void main(String[] args) {

        String  stringinput = "independent";  //decalaring and assigning variable
        char[] character =stringinput.toCharArray(); //convert string to character by using tochararray method

        for (int i=character.length - 1; i>=0 ; i--)
            System.out.println(character[i]);



    }
}
