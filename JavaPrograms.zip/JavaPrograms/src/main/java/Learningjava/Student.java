package Learningjava;

public class Student {

    //Learning THIS keyword in java
    //Learning current class instance variable
    //here we are using same name for instance variable and parameter ,so it causes ambuguity
    //To resolve we using this keyword for instance variable

    int rollno;  //Instance variable
    String name; //Instance variable
    float fees;  //Instance variable

    Student (int rollno,String name ,Float fees){  //this is parametertized ontructor as Student is same as class name


        this.rollno = rollno; //we are assigning  instance variable rollno to parameter rollno
        this.name = name;
        this.fees = fees;
        //we are using this to refer the instance variable
    }

        public void display(){ //Methods to display values
            System.out.println(rollno + name + fees) ;

        }
    public static void main(String[] args) {
        Student s1 = new Student(111,"Nazeer" ,200f);
        Student s2 = new Student(222,"baseer",300f);
        s1.display();
        s2.display();

        }



}






