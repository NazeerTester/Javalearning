package Learningjava;

public class LearnRelationalOperators {

    public static void main(String[] args) {

        int a=100;
        int b =200;

        System.out.println(a==b); //== returns true if both operand are true
        System.out.println(a!=b); // != reurns true if both operatd are NOT true
        System.out.println(a>b);
        System.out.println(a<b);
        System.out.println(a>=b);
        System.out.println(a<=b);

    }

}
