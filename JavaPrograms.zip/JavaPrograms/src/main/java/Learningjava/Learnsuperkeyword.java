package Learningjava;

public class Learnsuperkeyword {


    int salary = 500;


    public static void main(String[] args) {

    }
}
