package Learningjava;

public class Mrsubclass extends Learnsuperkeyword{

    int salary = 2000;

   void display(){

       System.out.println("salary is "  + super.salary);
       //super refers to salary from parent class here paten class is Learnssuperkeyword
   }

    public static void main(String[] args) {
        Mrsubclass obj = new Mrsubclass();
        obj.display();
    }


}
