package Practicejava;

public class Reversestring {

    //Reverse string without string inbuilt functions
    //Reverse string using Stringbuilder
    //In String buffer we are going to use append and reverse method


    public static void main(String[] args) {
        String str = "Automation is awesome";
        StringBuilder str2 = new StringBuilder();
        str2.append(str);
        str2=str2.reverse();
        System.out.println(str2);
    }
}
