package Practicejava;

import java.util.Scanner;

public class Reversestringwithoutreversemethod {


    public static void main(String[] args) {
        Scanner myobj = new Scanner(System.in);
       String username =myobj.nextLine();
        System.out.println("Enter the username");

       String[] test =username.split("Awesome");
    }
}
