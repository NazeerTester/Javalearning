package Practicejava;

public class Factorialwithloops {

    public static void main(String[] args) {

       int  i=1;
       int  fact =1;
       int number =5;

       //we need to get factorial of 5!

        for(i=1; i<=number;i++){

            fact = fact *i;
            // 1 = 1*1=1
            // 1= 1*2 = 2
            //2 = 1*3=3
            //3 = 1*4=5
            //4 =1*5=5


        }
        {
            System.out.println("Factorial of " + number + " is " + fact);
        }



    }
}
