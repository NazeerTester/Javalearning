package Practicejava;

public class RSAtCharacterarray {

    //Using Tocharracter array

    public static void main(String[] args) {
        String str = "John";
        char[] jerry =str.toCharArray();

        for (int i =jerry.length -1; i>=0; i--)
            System.out.println(jerry[i]);
    }
}
