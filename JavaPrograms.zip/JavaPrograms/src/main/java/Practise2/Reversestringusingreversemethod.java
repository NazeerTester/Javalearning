package Practise2;

public class Reversestringusingreversemethod {

    public static void main(String[] args) {

        String naz = "Super";
        StringBuilder srt = new StringBuilder();
         srt =srt.append(naz);
         srt=srt.reverse();
        System.out.println(srt);
    }
}
