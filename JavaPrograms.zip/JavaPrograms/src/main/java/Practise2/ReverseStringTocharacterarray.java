package Practise2;

public class ReverseStringTocharacterarray {


    //Reverse a string using tocharacter array

    public static void main(String[] args) {
        String std = "Nazeer";
        char[] fareen =std.toCharArray();

        for(int i=fareen.length -1; i>=0; i--)
            System.out.println(fareen[i]);
    }
}
