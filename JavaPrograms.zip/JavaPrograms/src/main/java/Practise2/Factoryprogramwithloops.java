package Practise2;

public class Factoryprogramwithloops {

    public static void main(String[] args) {
        int i =1;
        int number = 5;
        int fact =1;

        for (i = 1; i<=number; i++)

            fact = fact*i;

        System.out.println("Factorial of " + number + " is " + fact);

    }
}
